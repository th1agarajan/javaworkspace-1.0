/**
 * TypeFaceFactory.java
 */
package com.test;

import java.util.HashMap;
import java.lang.Character;

/**
 * @author www.javaworkspace.com
 * 
 */
public class TypeFaceFactory {
	public static int count = 0;
	public static int objectCount = 0;
	public static final HashMap<Character, KeyPad> HASH_MAP = new HashMap<Character, KeyPad>();

	public static KeyPad getLetter(Character letter) {
		TypeFace typeFace = (TypeFace) HASH_MAP.get(letter);
		if (typeFace == null) {
			typeFace = new TypeFace(letter);
			HASH_MAP.put(letter, typeFace);
			objectCount = objectCount + 1;
		}
		count = count + 1;
		return typeFace;
	}
}