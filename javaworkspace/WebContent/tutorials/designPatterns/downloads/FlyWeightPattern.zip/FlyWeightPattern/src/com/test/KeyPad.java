/**
 * KeyPad.java
 */
package com.test;

/**
 * @author www.javaworkspace.com
 * 
 */
public interface KeyPad {
	public String draw();
}