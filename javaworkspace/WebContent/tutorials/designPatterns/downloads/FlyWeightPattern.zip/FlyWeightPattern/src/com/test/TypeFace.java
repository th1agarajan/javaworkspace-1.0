/**
 * TypeFace.java
 */
package com.test;

/**
 * @author www.javaworkspace.com
 * 
 */
public class TypeFace implements KeyPad {

	private String fontColor;
	private int fontSize;
	private Character letter;

	public TypeFace(Character letter) {
		this.letter = letter;
	}

	public void setFontColor(String fontColor) {
		this.fontColor = fontColor;
	}

	public void setFontSize(int fontSize) {
		this.fontSize = fontSize;
	}

	@Override
	public String draw() {
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append("<td style='font-size:" + fontSize + "px; color: "
				+ fontColor + ";'>");
		stringBuffer.append(letter);
		stringBuffer.append("</td>");
		return stringBuffer.toString();
	}
}