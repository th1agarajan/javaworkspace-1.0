/**
 * WordProcessor.java
 */
package com.test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

/**
 * @author www.javaworkspace.com
 * 
 */
public class WordProcessor {

	private static final String FILE_NAME = "C:/flyWeightPattern.html";
	private static final String colors[] = { "red", "green", "orange", "blue",
			"black" };
	private static final Character alphabets[] = { 'A', 'B', 'C', 'D', 'E' };
	private static final StringBuffer output = new StringBuffer();

	public static void main(String[] args) {
		WordProcessor notePad = new WordProcessor();
		notePad.typeFace();
	}

	public void typeFace() {
		for (int i = 0; i < 20; ++i) {
			TypeFace ob = (TypeFace) TypeFaceFactory
					.getLetter(getRandomAlphabet());
			ob.setFontColor(getRandomColor());
			ob.setFontSize(getRandomFontSize());
			String temp = ob.draw();
			preFormat(temp);
		}

		if (isCreateFile(format(output.toString()))) {
			System.out.println("Check the output at the location " + FILE_NAME);
		} else {
			System.out.println("Failed to create output");
		}
	}

	private void preFormat(String temp) {
		output.append(temp);
		output.append("\n");
	}

	private String format(String input) {
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append("<html>");
		stringBuffer.append("\n");
		stringBuffer.append("<title>");
		stringBuffer.append("\n");
		stringBuffer
				.append("Fly Weight Pattern Example - www.javaworkspace.com");
		stringBuffer.append("\n");
		stringBuffer.append("</title>");
		stringBuffer.append("\n");
		stringBuffer.append("<body>");
		stringBuffer.append("\n");
		stringBuffer.append("<table>");
		stringBuffer.append("\n");
		stringBuffer.append("<tr>");
		stringBuffer.append("\n");
		stringBuffer.append(input);
		stringBuffer.append("</tr>");
		stringBuffer.append("\n");
		stringBuffer.append("<tr>");
		stringBuffer.append("\n");
		stringBuffer.append("<td colspan='20'>Number of letters printed: "
				+ TypeFaceFactory.count + "</td>");
		stringBuffer.append("</tr>");
		stringBuffer.append("\n");
		stringBuffer.append("<tr>");
		stringBuffer.append("\n");
		stringBuffer
				.append("<td colspan='20'>Number of TypeFace Objects created: "
						+ TypeFaceFactory.objectCount
						+ " - For each unique alphabet one oject is created.</td>");
		stringBuffer.append("</tr>");
		stringBuffer.append("\n");
		stringBuffer.append("</table>");
		stringBuffer.append("\n");
		stringBuffer.append("</body>");
		stringBuffer.append("\n");
		stringBuffer.append("</html>");
		return stringBuffer.toString();
	}

	private String getRandomColor() {
		return colors[(int) (Math.random() * colors.length)];
	}

	private Character getRandomAlphabet() {
		return alphabets[(int) (Math.random() * alphabets.length)];
	}

	private int getRandomFontSize() {
		return new Random().nextInt(60) + 10;
	}

	private boolean isCreateFile(String content) {
		boolean status = false;
		try {
			File file = new File(FILE_NAME);
			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
			FileWriter fileWriter = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			bufferedWriter.write(content);
			bufferedWriter.close();
			status = true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return status;
	}
}
